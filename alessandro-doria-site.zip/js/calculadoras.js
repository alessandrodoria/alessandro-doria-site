
function money(v){return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(v)}
function n(id){return Number(document.getElementById(id)?.value||0)}

function calcOrcamento(){
  const renda=n("renda"), fixa=n("fixa"), variavel=n("variavel"), dividas=n("dividas"), invest=n("invest");
  const despesas=fixa+variavel+dividas, saldo=renda-despesas-invest;
  document.getElementById("orc-result").innerHTML=`<strong>${money(saldo)}</strong><span>Saldo mensal estimado após despesas e investimentos.</span>`;
}
function calcJuros(){
  const inicial=n("inicial"), aporte=n("aporte"), taxa=n("taxa")/100, meses=n("meses");
  const futuro=inicial*Math.pow(1+taxa,meses)+aporte*((Math.pow(1+taxa,meses)-1)/taxa || meses);
  const total=inicial+aporte*meses;
  document.getElementById("juros-result").innerHTML=`<strong>${money(futuro)}</strong><span>Total aportado: ${money(total)}. Resultado é uma simulação matemática.</span>`;
}
function calcReserva(){
  const gastos=n("gastos"), meses=n("resmeses");
  document.getElementById("res-result").innerHTML=`<strong>${money(gastos*meses)}</strong><span>Valor correspondente a ${meses} meses de gastos.</span>`;
}
function calcDivida(){
  const parcela=n("parcela"), qtd=n("qtd");
  document.getElementById("div-result").innerHTML=`<strong>${money(parcela*qtd)}</strong><span>Total nominal das parcelas informadas.</span>`;
}
