
const SITE = {
  whatsapp: "5500000000000",
  email: "contato@seudominio.com.br",
  instagram: "https://instagram.com/",
  youtube: "https://youtube.com/",
  linkedin: "https://linkedin.com/",
  analyticsId: "" // Ex.: G-XXXXXXXXXX
};

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-year]").forEach(el => el.textContent = new Date().getFullYear());

  const toggle = document.querySelector(".menu-toggle");
  const menu = document.querySelector(".menu");
  if (toggle && menu) toggle.addEventListener("click", () => menu.classList.toggle("open"));

  document.querySelectorAll("[data-whatsapp]").forEach(a => {
    const text = a.dataset.whatsapp || "Olá, Alessandro! Gostaria de saber mais sobre sua consultoria.";
    a.href = `https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(text)}`;
  });
  document.querySelectorAll("[data-email]").forEach(a => a.href = `mailto:${SITE.email}`);
  document.querySelectorAll("[data-instagram]").forEach(a => a.href = SITE.instagram);
  document.querySelectorAll("[data-youtube]").forEach(a => a.href = SITE.youtube);
  document.querySelectorAll("[data-linkedin]").forEach(a => a.href = SITE.linkedin);

  if (SITE.analyticsId) {
    const s = document.createElement("script");
    s.async = true;
    s.src = `https://www.googletagmanager.com/gtag/js?id=${SITE.analyticsId}`;
    document.head.appendChild(s);
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments)}
    window.gtag = gtag;
    gtag("js", new Date());
    gtag("config", SITE.analyticsId);
  }

  const year = document.querySelector("#year");
  if (year) year.textContent = new Date().getFullYear();
});
