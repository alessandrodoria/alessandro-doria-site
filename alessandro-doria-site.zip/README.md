# Alessandro Dória — Site Profissional

Site estático profissional para **Alessandro Dória — Consultor Financeiro**.

## Estrutura
- `index.html` — página inicial
- `consultoria.html` — consultoria financeira
- `palestras.html` — palestras e treinamentos
- `ebooks.html` — vitrine de e-books
- `blog.html` — artigos
- `materiais.html` — materiais gratuitos
- `calculadoras.html` — calculadoras financeiras
- `contato.html` — contato e formulário
- `privacidade.html`, `cookies.html`, `termos.html` — páginas legais
- `css/style.css` — identidade visual
- `js/main.js` — navegação e interações
- `js/calculadoras.js` — calculadoras
- `assets/img/` — imagens locais a substituir

## Antes de publicar
1. Substitua a foto `assets/img/alessandro-placeholder.svg` por uma fotografia profissional.
2. Edite `js/main.js` e altere `SITE.whatsapp`, `SITE.email` e redes sociais.
3. Substitua os links dos e-books e materiais pelos seus links reais.
4. Crie os formulários no Tally e cole os URLs nos locais indicados.
5. Insira seu ID do Google Analytics em `js/main.js` se quiser medir acessos.
6. Revise as páginas de Privacidade, Cookies e Termos com seus dados reais.
7. Publique em Cloudflare Pages.

## Hospedagem recomendada
Cloudflare Pages para este projeto estático. O projeto foi desenhado para não depender de servidor próprio.

## Importante
Não coloque dados confidenciais de clientes no repositório. Este site é institucional e educativo; diagnósticos financeiros devem ser realizados em ambiente apropriado e seguro.
